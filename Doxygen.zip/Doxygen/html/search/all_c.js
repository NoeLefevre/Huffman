var searchData=
[
  ['stack_47',['Stack',['../struct_stack.html',1,'']]],
  ['structure_2eh_48',['Structure.h',['../_structure_8h.html',1,'']]]
];
