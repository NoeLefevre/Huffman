var searchData=
[
  ['pop_95',['pop',['../_pile_8h.html#a848483c4d76961dec185e68aa63ab96e',1,'Pile.c']]],
  ['push_96',['push',['../_pile_8h.html#a2399708ade6984e3d2ae1f43ae0b2398',1,'Pile.c']]]
];
